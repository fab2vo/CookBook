<?php
/* Program: findchain.php
 * Fin chain in Solutions.csv file 
 * input : idchain
 * 
 */
 $idchain=$_POST['idchain'];
 $filename="Solutions.csv";
 echo "<h1 >Recherche des combinaisons de cartes</h1>";
 echo "<p>Recherche de ".$idchain."</p>";
 $row = 1;
 $found=FALSE;
if (($handle = fopen($filename, "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $num = count($data);
        #echo "<p> $num fields in line $row: <br /></p>\n";
        $row++;
		if ($idchain==$data[0]) {
			if (! $found) { echo "<p>Trouve !</p>"."<br />\n";}
			$found=True;
			echo "Cost    GHG     H20     Land    Protest"."<br />\n";
			for ($c=1; $c < 6; $c++) {
				echo sprintf("%01.2f", $data[$c]) . "   ";
			}
			if ($data[2]<5){
				if (($data[3]<20)&&($data[4]<50)&&($data[5]<20)) {
					if ($data[2]<1) {
						echo " passe le challenge ultimate";
					} else {
						echo " passe le challenge sustainable";
					}
					
				} else{
					echo " passe le challenge bas carbone";
				}
			}
			echo "<br />\n";
			echo "Local <br />\n";
			echo "Elec   H2   CH4  BioCH4  Biomass Coal"."<br />\n";
			echo sprintf("%01.2f", $data[6]+$data[9]) . "   ";
			echo sprintf("%01.2f", $data[7]+$data[10]) . "   ";
			echo sprintf("%01.2f", $data[8]) . "   ";
			echo sprintf("%01.2f", $data[11]) . "   ";
			echo sprintf("%01.2f", $data[13]) . "   ";
			echo sprintf("%01.2f", $data[14]) . "   ";
			echo "<br />\n";
			echo "Import <br />\n";
			echo "Elec   H2   CH4  BioCH4  Biomass Coal"."<br />\n";
			echo sprintf("%01.2f", $data[16]+$data[19]) . "   ";
			echo sprintf("%01.2f", $data[17]+$data[20]) . "   ";
			echo sprintf("%01.2f", $data[18]) . "   ";
			echo sprintf("%01.2f", $data[21]) . "   ";
			echo sprintf("%01.2f", $data[23]) . "   ";
			echo sprintf("%01.2f", $data[24]) . "   ";
			echo "<br />\n";
			echo "<br />\n";
		}
    }
	if (! $found) {echo "Not found";} 
    fclose($handle);
}
 
 ?>