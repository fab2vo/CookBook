<?php
echo "Fichier tiers";
?>